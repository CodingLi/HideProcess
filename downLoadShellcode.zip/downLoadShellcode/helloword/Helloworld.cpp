#include <windows.h>
#include <stdio.h>

int main()
{
	printf("hello world...\n");
	system("pause");
}